# REPLIKA V1.4 · дизайн-лаборатория

Статус: **HUMAN_CONCEPT_REVIEW_PENDING**. Нативная V1.4 ещё не реализована. Android-исходники V1.3 сохранены. Все макеты и browser captures здесь — концепты, не доказательство Android runtime.

Ветка: `feature/replika-v1.4-visual`; исходный HEAD: `ce345569377f0d7b60b383296f00f58b417986e0`. Ранее существовавшая неотслеживаемая папка `video-production-fi-20261105/` не изменяется. Предыдущий APK остаётся в `release/REPLIKA-V1.3-AllInOne-arm64.apk`.

Локальный просмотр: `python3 -m http.server 4174 --bind 0.0.0.0 --directory design-lab`, затем `http://localhost:4174`. В Frontend Intelligence Desktop V2 выбрать проект `F:\Hackathons\ReplikaAndroid`, открыть этот адрес через Live Preview / «Найти сайт». Дизайн-лаборатория использует только локальные файлы и не подключена к Gradle.

Материалы: [аудит](AUDIT.md), [контракт FI](FRONTEND_INTELLIGENCE.md), [сравнение](review/HUMAN_CONCEPT_REVIEW.md), `evidence/baseline/` и `evidence/browser/`. Живые экраны используют явно вымышленные данные. Waveform концепта демонстрационный. Сохранение в лаборатории не изменяет Room.

Выбор может быть целым направлением либо обратной связью KEEP / REMOVE / COMBINE / AMPLIFY / REINTERPRET / REJECT / REJECT ALL. После фактического выбора фиксируется synthesis brief; затем реализуется Compose и выполняется нативная приёмка из задания. APK, SHA, Android-скриншоты V1.4 и финальные отчёты поставляются после этого этапа, не заранее.

Повторить browser QA на сохранённом FI Chromium (системные Playwright1248 binaries в окружении оказались обрезаны):

```bash
LD_LIBRARY_PATH=/home/egor/frontend-intelligence-runtime/20261102-recovery/recovery/local-libs/usr/lib/x86_64-linux-gnu node design-lab/tools/verify.cjs
```

Сервер должен быть запущен. Скрипт использует уже установленный Playwright Desktop V2, проверяет восемь экранов каждого направления в двух размерах, дополнительные состояния, seek/filter/edit/Reading/copy/export/review, cancel/retry и reduced motion. Он перезаписывает только lab captures и report.json. Не изменяет Android, модели, Room или app data. Начальные browser-launch failures сохранены отдельно.
