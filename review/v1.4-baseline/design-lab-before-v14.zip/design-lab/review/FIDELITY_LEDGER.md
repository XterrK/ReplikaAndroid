# Проверка визуальной точности concept lab

Статус: сравнение исследовательских направлений; **нет утверждённого дизайна**, нет agency sign-off / human approval. После выбора точный spec будет зафиксирован отдельно. Здесь перечислены осознанные отличия от imagegen, а не объявлена буквальная fidelity к неутверждённым изображениям.

| Область | Imagegen evidence | Browser evidence | Действие / отличие |
|---|---|---|---|
| Состав экранов | a/b/c-overview.png | 3×8 основных экранов | Все восемь состояний представлены отдельно; grids imagegen не используются как mobile-fit proof |
| Цвет | A near-black/amber, B graphite/blue, C paper/teal/rust | comparison-desktop.png | Палитры удержаны; без имитации текстуры/градиента/шумового bitmap |
| Типографика | A/B sans, C editorial serif | dialogue/reading captures | Onest local OFL добавлен для UI и sans направлений; C serif остаётся платформенным prototype fallback, точный font выбирается в native spec |
| Истинность текста | C overview подменяет transcript пересказом | c-reading-* | Сохранён source text без генеративного пересказа; это обязательное product-correctness отличие |
| Аудиоинтерфейс | A показывает дополнительные meters и параметры | a-dialogue-* / a-recording-* | Лишние L/R meters, sample-rate controls и выдуманные функции не перенесены |
| Семантика моделей | b-dialogue-rejected.png выдумывает модели и CLI | b-models-* | Portrait rejected как product spec; только реальный список backend types в synthetic state |
| Плотность | Большие imagegen панели не доказывают compact fit | *-360x640.png | Все направления адаптируют высоту chrome, content остаётся прокручиваемым |
| Reading | Boards включают имена и лишний chrome | *-reading-* | Чистые слова из тех же сегментов; compact transport, copy/export |
| Доступность редактирования | Imagegen неоднозначен | *-dialogue-* / *-editor-* | Всегда видимый ellipsis, явный label «Сохранить», 48px control |
| Время / timeline | Generated шкала может не совпадать с turns | DOM fixture + interaction checks | Положение полос считается по source start/duration, реальные паузы сохраняются, active seek проверен |
| Клавиатура | Generated keyboard | *-editor-* | Синтетическая IME явно обозначена; native insets/IME acceptance не заявляется |
| Motion | Статические concepts | reduced-motion checks в report.json | Короткие CSS feedback переходы отключаются при prefers-reduced-motion; Compose spec пока не принят |

Above-the-fold copy сверялось по фактическому product brief: названия экранов, model types и actions соответствуют задаче; imagegen-текст не авторитетен для product facts. Дополнительная полоса «Дизайн-концепт · не Android» и lab disclaimers сознательно добавлены для корректной provenance, не являются будущим UI продукта.

Автор просмотрел через view_image все три overview, desktop comparison, compact editor и reading, а также индивидуальные dialogue renders. Независимый reviewer отдельно проверяет обновлённые renders. Допустимые изменения и остаточные риски перечислены выше; 10/10 fidelity или финальная нативная готовность не заявляются.
